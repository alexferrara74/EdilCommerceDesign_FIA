#!/Library/Frameworks/Python.framework/Versions/3.6/bin/python3.6
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sqldf as sqldf
from pandas.io.parsers.readers import read_csv
from sklearn import preprocessing
from array import array
from tkinter import *
from tokenize import String

from sklearn.cluster import KMeans
from sklearn.preprocessing import scale

df = pd.read_csv("dataset/datasetQntNs.csv")
dp = pd.read_csv("dataset/datasetProdotti.csv")
dc = pd.read_csv("dataset/datasetCategorie.csv")
dc= dc.filter(regex="^(?!Unnamed)", axis=1)

def creazioneArray():
    categoria = df["category_code"].value_counts()
    categoria.sort_index(inplace=True)
    ordine = df.groupby("category_code").sum()["order_id"]
    ordine.sort_index(inplace=True)
    x = categoria.values
    y = ordine.values
    X = np.array(list(zip(x,y)))
    return X

def algoritmo(X):
    #K-MEANS
    kmeans = KMeans(n_clusters=6)
    kmeans.fit(X)
    #aggiungiamo la colonna cluster
    dc["cluster"]=kmeans.labels_
    temp =dp.merge(dc)
    temp= temp.filter(regex="^(?!Unnamed)", axis=1)
    temp= temp.filter(regex="^(?!qnt)", axis=1)
    temp= temp.filter(regex="^(?!category_id)", axis=1)
    return temp

def clusterDP(temp, prodotto):
    #individuiamo il cluster mediante il prodotto
    j=0
    while j < len(temp):    #1515966223509089696
        if temp.product_id[j]==prodotto:
            print("Brand: ",temp.brand[j])
            print("Cluster: ",temp.cluster[j])
            print("Categoria: ",temp.category_code[j])
            clusterP=temp.cluster[j]
            break
        j += 1
    return clusterP

def categorieC(clusterP):
    #individuiamo le categorie del cluster
    lista=[]
    j=0
    while j < len(dc):
        if dc.cluster[j]==clusterP:
            print(dc.category_code[j])
            lista.append(dc.category_code[j])
        j += 1
    return lista

def listaProdotti(lista):
    risultatoP= []
    j=0
    while j < len(lista):
        q="select product_id, count(product_id) as qnt, brand, price, category_code from df where category_code='"+lista[j]+"' group by product_id order by qnt asc"
        r=sqldf.run(q)
        risultatoP.append(r.product_id[0])
        risultatoP.append(r.brand[0])
        risultatoP.append(r.price[0])
        j += 1
    print(risultatoP)
    return risultatoP




def avvia():
    window.destroy()
    def callback():
        sindex = listbox.curselection()
        itmText = listbox.get(sindex)
        print(itmText)
        dCategorie = algoritmo(arrayC)
        clusterPr = clusterDP(dCategorie, itmText)
        listaC = categorieC(clusterPr)
        output = listaProdotti(listaC)
        pConsigliati = Label(scheda, text = "Prodotti consigliati: {0}".format(int(len(output)/3)))
        pConsigliati.place(x=300,y=60)
        listaOut.delete(0,END)
        for entry in output:
            listaOut.insert(END, entry)
            listaOut.pack()
            listaOut.place(x=300, y=80)
    scheda= Tk()
    scheda.geometry("600x400")
    scheda.title("INVENDUM")
    L1 = Label(scheda, text = "INVENDUM",font=200)
    L1.place(x=200,y=10)

    arrayC=creazioneArray()
    listbox = Listbox(scheda)
    listaOut = Listbox(scheda)
    for entry in dp.product_id:
        listbox.insert(END, entry)
    lProdotti = Label(scheda, text = "Lista Prodotti")
    lProdotti.place(x=100,y=60)
    listbox.pack()
    listbox.place(x=100, y=80)
    b1= Button(scheda,text = "Seleziona-Prodotto",command=callback , width=50)
    b1.place(x = 100,y = 300)

#inizio
window = Tk()
window.geometry("600x300")
window.title("INVENDUM")

L1 = Label(window, text = "INVENDUM",font=100)
L1.place(x=240,y=30)

B = Button(window, text = "ENTRA NEL NOSTRO E-COMMERCE", command = avvia,width=30)
B.place(x = 180,y = 100)

if __name__ == "__main__":
    window.mainloop()
